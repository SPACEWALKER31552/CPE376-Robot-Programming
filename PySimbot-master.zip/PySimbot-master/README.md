## PySimbot

PySimbot is a software for simple robot simulation

## Documentation

See this [Wiki](https://github.com/jetstreamc/PySimbot/wiki/)

## Copyleft license

This software is under the GPL-GNU License as declared in [LICENSE](/LICENSE) file.